(select book.isbn, book.title, authors.name from 
book 
inner join book_authors on book.isbn = book_authors.isbn 
inner join authors on book_authors.author_id = authors.author_id where authors.name like '%new%')
union all 
(select book.isbn, book.title, authors.name from 
book 
inner join book_authors on book.isbn = book_authors.isbn 
inner join authors on book_authors.author_id = authors.author_id where book.title like '%new%')
union all
(select book.isbn, book.title, authors.name from 
book 
inner join book_authors on book.isbn = book_authors.isbn 
inner join authors on book_authors.author_id = authors.author_id where book.isbn like '%new%');