#Drop all tables
drop table fines;
drop table book_loans;
drop table borrower;
drop table authors;
drop table book_authors;
drop table book;

#Creating book table
create table book(isbn varchar(20), title char(50), primary key(isbn));


 
#Creating authors table
create table authors(author_id varchar(20), name char(50), primary key(author_id));

					
#Creating book_authors
create table book_authors(author_id varchar(20), isbn varchar(20),
						primary key(author_id, isbn),
						foreign key(author_id) references authors(author_id),
						foreign key(isbn) references book(isbn) on delete cascade);

						
#Create borrower table
create table borrower(card_id int not null auto_increment, ssn varchar(15) not null unique, fname char(50) not null,
		address char(50) not null, phone char(15), primary key(card_id));
		
#Create book_loans table
create table book_loans(loan_id int auto_increment, isbn varchar(20), card_id int,
						date_out date, due_date date, date_in date,
						primary key(loan_id), foreign key(isbn) references book(isbn),
						foreign key(card_id) references borrower(card_id) on delete cascade);
						
#Create table for fines
create table fines(loan_id int, fine_amt decimal(5,2), paid char(5), primary key(loan_id),
					foreign key(loan_id) references book_loans(loan_id));
					