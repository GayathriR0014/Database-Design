select book_loans.card_id, sum(fines.fine_amt) from book_loans, fines group by book_loans.card_id
where book_loans.loan_id = fines.loan_id;  