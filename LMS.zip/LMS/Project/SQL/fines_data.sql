# Late book, not returned
insert into fines 
	select loan_id, datediff(CURDATE(),due_date)/4,'FALSE' from book_loans 
	where book_loans.date_in is null and CURDATE()>due_date;
	
#update fines set fine_amt= (CURDATE()-book_loans.due_date)/4
#	where loan_id=(select loan_id from book_loans where book_loans.date_in is null and CURDATE()>due_date);
	
	
	
# Late Book, returned, fine not paid
insert into fines 
	select loan_id, datediff(date_in,due_date)/4,'FALSE' from book_loans 
	where book_loans.date_in is not null and date_in>due_date;

#update fines set fine_amt = (date_in-due_date)/4 
#	where loan_id=(select loan_id from book_loans where book_loans.date_in is not null and date_in>due_date)
#	and paid='FALSE';
	
# Late Book, returned, fine paid => do nothing
	
# Not late, not returned
insert into fines 
	select loan_id, 0, 'FALSE' from book_loans 
	where book_loans.date_in is null and CURDATE()<=due_date;
	
#update fine set fine_amt = 0 
#	where loan_id=(select loan_id from book_loans where book_loans.date_in is null and CURDATE()<=due_date);
	
# Not late, returned
insert into fines 
	select loan_id, 0, 'FALSE' from book_loans 
	where book_loans.date_in is not null and date_in<=due_date;
	
#update fines set fine_amt = 0 
#	where loan_id=(select loan_id from book_loans where book_loans.date_in is not null and CURDATE()<=due_date);
	
	
	